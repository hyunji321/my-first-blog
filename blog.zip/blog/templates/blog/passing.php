<?php

$data = $_POST['data'];


echo $data;

 ?>
